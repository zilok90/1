#!/bin/sh
./miner --algo grin29 --server grin.sparkpool.com --port 6666 --user admin@develsoftware.com/rig0
